# My Poems Package

This package contains two poems: a favorite and a least favorite.

## Usage

```python
import mypoems

print(mypoems.favorite_poem)
print(mypoems.least_favorite_poem)
```
