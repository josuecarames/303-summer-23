favorite_poem = """
Sabe, si alguna vez tus labios rojos
quema invisible atmósfera abrasada,
que el alma que hablar puede con los ojos,
también puede besar con la mirada.
"""

least_favorite_poem = """
En el rincón más olvidado,
donde el viento no canta y el sol no brilla,
ahí yace un verso,
olvidado por el tiempo, ignorado por la rima.
"""